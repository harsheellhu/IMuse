import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar, MobileNav } from './Navbar';
import { PostDetailViewer } from '../viewer/PostDetailViewer';

export function AppLayout() {
  return (
    <div className="min-h-screen text-text-primary font-sans antialiased selection:bg-text-primary selection:text-bg-base transition-colors duration-500">
      <Navbar />
      <main className="pt-24 pb-32 md:pb-12 min-h-screen max-w-full overflow-x-hidden">
        <Outlet />
      </main>
      <MobileNav />
      <PostDetailViewer />
    </div>
  );
}
