import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Plus, User, Compass, Moon, Sun, Laptop, Palette } from 'lucide-react';
import { useStore, Theme, ColorMode } from '../../store/useStore';
import clsx from 'clsx';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';

export function Navbar() {
  const location = useLocation();
  const { currentUser, theme, setTheme, colorMode, setColorMode } = useStore();
  const [searchFocused, setSearchFocused] = useState(false);
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);
  const [colorMenuOpen, setColorMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  
  // Make navbar background appear on scroll
  const bgOpacity = useTransform(scrollY, [0, 50], [0, 0.85]);
  const blur = useTransform(scrollY, [0, 50], [0, 16]);
  
  // Check if we are in dark mode visually
  const isDark = document.documentElement.classList.contains('dark');

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'Explore World', path: '/explore' },
    { label: 'Books', path: '/books' },
    { label: 'Films', path: '/films' },
    { label: 'Collections', path: '/collections' },
  ];

  return (
    <motion.nav 
      className="fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-5 flex items-center justify-between transition-all duration-500"
      style={{ 
        backgroundColor: useTransform(bgOpacity, v => 
          isDark ? `rgba(10, 10, 10, ${v})` : `rgba(253, 252, 251, ${v})`
        ),
        backdropFilter: useTransform(blur, v => `blur(${v}px)`)
      }}
    >
      <div className="flex items-center gap-12">
        <Link to="/" className="text-xl font-serif font-medium tracking-tight text-text-primary">IMuse</Link>
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={clsx(
                'text-[13px] tracking-wide transition-colors duration-300',
                location.pathname === item.path ? 'text-text-primary font-medium' : 'text-text-secondary hover:text-text-primary'
              )}
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className={clsx(
          "relative hidden md:flex items-center transition-all duration-500 ease-out",
          searchFocused ? "w-64" : "w-10 opacity-60 hover:opacity-100"
        )}>
          <Search className={clsx(
            "absolute w-4 h-4 text-text-primary pointer-events-none z-10 transition-all duration-500",
            searchFocused ? "left-3" : "left-3"
          )} />
          <input 
            type="text" 
            placeholder={searchFocused ? "Search IMuse..." : ""} 
            className={clsx(
              "w-full h-10 rounded-full text-sm text-text-primary focus:outline-none transition-all duration-500 bg-transparent placeholder:text-text-muted",
              searchFocused ? "pl-10 pr-4 bg-bg-secondary" : "cursor-pointer"
            )}
            onFocus={() => setSearchFocused(true)}
            onBlur={() => setSearchFocused(false)}
          />
        </div>

        <button className="hidden md:flex items-center justify-center w-10 h-10 rounded-full text-text-primary hover:bg-bg-secondary transition-colors duration-300">
          <Plus className="w-5 h-5" />
        </button>

        {/* Color Mode Toggler */}
        <div className="relative hidden md:block">
          <button 
            onClick={() => {
              setColorMenuOpen(!colorMenuOpen);
              setThemeMenuOpen(false);
            }}
            className="flex items-center justify-center w-10 h-10 rounded-full text-text-primary hover:bg-bg-secondary transition-colors duration-300"
          >
            <Palette className="w-4 h-4" />
          </button>
          
          <AnimatePresence>
            {colorMenuOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute top-12 right-0 w-36 bg-bg-elevated border border-border-subtle rounded-xl shadow-lg py-2 flex flex-col z-50 overflow-hidden"
              >
                {(['neutral', 'warm', 'cool'] as ColorMode[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => { setColorMode(c); setColorMenuOpen(false); }}
                    className={clsx(
                      "px-4 py-2 text-sm text-left flex items-center gap-3 hover:bg-bg-secondary transition-colors",
                      colorMode === c ? "text-text-primary font-medium" : "text-text-secondary"
                    )}
                  >
                    <div className={clsx(
                      "w-3 h-3 rounded-full border border-border-subtle",
                      c === 'neutral' ? "bg-[#FDFCFB] dark:bg-[#0A0A0A]" :
                      c === 'warm' ? "bg-[#FAF6F0] dark:bg-[#14110E]" :
                      "bg-[#F5F7FA] dark:bg-[#0A0E17]"
                    )} />
                    <span className="capitalize">{c}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Theme Toggler */}
        <div className="relative hidden md:block">
          <button 
            onClick={() => {
              setThemeMenuOpen(!themeMenuOpen);
              setColorMenuOpen(false);
            }}
            className="flex items-center justify-center w-10 h-10 rounded-full text-text-primary hover:bg-bg-secondary transition-colors duration-300"
          >
            {theme === 'dark' ? <Moon className="w-4 h-4" /> : theme === 'light' ? <Sun className="w-4 h-4" /> : <Laptop className="w-4 h-4" />}
          </button>
          
          <AnimatePresence>
            {themeMenuOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute top-12 right-0 w-36 bg-bg-elevated border border-border-subtle rounded-xl shadow-lg py-2 flex flex-col z-50 overflow-hidden"
              >
                {(['light', 'dark', 'system'] as Theme[]).map((t) => (
                  <button
                    key={t}
                    onClick={() => { setTheme(t); setThemeMenuOpen(false); }}
                    className={clsx(
                      "px-4 py-2 text-sm text-left flex items-center gap-3 hover:bg-bg-secondary transition-colors",
                      theme === t ? "text-text-primary font-medium" : "text-text-secondary"
                    )}
                  >
                    {t === 'light' ? <Sun className="w-4 h-4" /> : t === 'dark' ? <Moon className="w-4 h-4" /> : <Laptop className="w-4 h-4" />}
                    <span className="capitalize">{t}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <Link to={`/profile/${currentUser.id}`} className="block w-8 h-8 rounded-full overflow-hidden transition-transform duration-300 hover:scale-105 border border-border-subtle">
          <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
        </Link>
      </div>
    </motion.nav>
  );
}

export function MobileNav() {
  const location = useLocation();
  
  const navItems = [
    { icon: Compass, path: '/' },
    { icon: Search, path: '/explore' },
    { icon: Plus, path: '/create' },
    { icon: User, path: '/profile/me' },
  ];

  return (
    <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 bg-bg-elevated/90 backdrop-blur-xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.2)] border border-border-subtle z-50 flex items-center justify-center gap-2 px-4 py-2 rounded-full">
      {navItems.map((item, idx) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.path || (item.path === '/profile/me' && location.pathname.startsWith('/profile'));
        return (
          <Link key={idx} to={item.path} className="p-3 rounded-full hover:bg-bg-secondary transition-colors">
            <Icon className={clsx("w-5 h-5 transition-colors duration-300", isActive ? "text-text-primary" : "text-text-muted")} />
          </Link>
        );
      })}
    </div>
  );
}
