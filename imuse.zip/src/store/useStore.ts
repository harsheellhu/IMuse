import { create } from 'zustand';
import { User, Post, Collection, Book, Film } from '../types';
import { currentUser, mockUsers, mockPosts, mockCollections, mockBooks, mockFilms } from '../data/mockData';

export type Theme = 'light' | 'dark' | 'system';
export type ColorMode = 'neutral' | 'warm' | 'cool';

export interface ActiveViewerItem {
  id: string;
  type: 'post' | 'book' | 'film' | 'collection';
  data: Post | Book | Film | Collection;
}

interface StoreState {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  colorMode: ColorMode;
  setColorMode: (mode: ColorMode) => void;
  currentUser: User;
  users: User[];
  posts: Post[];
  collections: Collection[];
  books: Book[];
  films: Film[];
  savedPostIds: Set<string>;
  toggleSavePost: (postId: string) => void;
  addPost: (post: Post) => void;
  activeViewerItem: ActiveViewerItem | null;
  openViewer: (item: ActiveViewerItem) => void;
  closeViewer: () => void;
}

export const useStore = create<StoreState>((set) => {
  // Initialize theme from localStorage or default to system
  const savedTheme = (localStorage.getItem('imuse-theme') as Theme) || 'system';
  const savedColorMode = (localStorage.getItem('imuse-color-mode') as ColorMode) || 'neutral';

  return {
    theme: savedTheme,
    setTheme: (theme) => {
      localStorage.setItem('imuse-theme', theme);
      set({ theme });
    },
    colorMode: savedColorMode,
    setColorMode: (colorMode) => {
      localStorage.setItem('imuse-color-mode', colorMode);
      set({ colorMode });
    },
    currentUser,
    users: mockUsers,
    posts: mockPosts,
    collections: mockCollections,
    books: mockBooks,
    films: mockFilms,
    savedPostIds: new Set<string>(),
    activeViewerItem: null,
    
    openViewer: (item) => set({ activeViewerItem: item }),
    closeViewer: () => set({ activeViewerItem: null }),
    
    toggleSavePost: (postId) => set((state) => {
      const newSaved = new Set(state.savedPostIds);
      if (newSaved.has(postId)) {
        newSaved.delete(postId);
      } else {
        newSaved.add(postId);
      }
      return { savedPostIds: newSaved };
    }),
    
    addPost: (post) => set((state) => ({
      posts: [post, ...state.posts]
    })),
  };
});
