import React from 'react';
import { useStore } from '../store/useStore';
import { MasonryFeed } from '../components/feed/MasonryFeed';
import { Carousel } from '../components/ui/Carousel';
import { motion, useScroll, useTransform } from 'motion/react';

export function Home() {
  const { posts, openViewer } = useStore();
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);

  // Split posts for different sections
  const heroPosts = posts.slice(0, 3);
  const carouselPosts = posts.slice(2, 10);
  const masonryPosts = posts.slice(10, 50);

  return (
    <div className="w-full">
      {/* Living Visual Gallery Hero */}
      <section className="relative w-full h-[90vh] flex items-center justify-center overflow-hidden mb-24">
        <motion.div 
          className="absolute inset-0 z-0 flex items-center justify-center gap-4 md:gap-8 opacity-40 md:opacity-100"
          style={{ y }}
        >
          {heroPosts.map((post, i) => (
            <motion.div 
              key={post.id}
              onClick={() => openViewer({ id: post.id, type: 'post', data: post })}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: i * 0.2, ease: [0.16, 1, 0.3, 1] }}
              className={`relative overflow-hidden cursor-pointer ${i === 1 ? 'w-[40vw] h-[60vh] z-10' : 'w-[25vw] h-[45vh] mt-24 z-0 hidden md:block'}`}
            >
              <img src={post.imageUrl} alt="" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" />
            </motion.div>
          ))}
        </motion.div>
        
        <div className="relative z-20 text-center flex flex-col items-center mix-blend-difference pointer-events-none">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl lg:text-8xl font-serif tracking-tight text-[#fff]"
          >
            Things worth keeping.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="mt-6 text-sm uppercase tracking-widest text-[#aaa] font-medium"
          >
            Explore the archive
          </motion.p>
        </div>
      </section>

      {/* Editorial Carousel Section */}
      <Carousel items={carouselPosts} title="Recent Discoveries" />

      {/* White space transition */}
      <div className="h-32 w-full"></div>

      {/* Masonry Field */}
      <section>
        <div className="px-4 md:px-12 mb-8 flex justify-between items-end">
          <h2 className="text-sm font-medium tracking-widest uppercase text-text-secondary">Visual Field</h2>
        </div>
        <MasonryFeed posts={masonryPosts} />
      </section>
    </div>
  );
}
